#ifndef DEF_H
#define DEF_H

#define EXTERN_DECL

extern int CounterSuiteSetup;

#endif //DEF_H
